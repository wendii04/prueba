Prueba Técnica:
Para esta prueba utilice JS, HTML Y CSS(LESS),

Los problemas que se me presentaron fueron:

1.No pude consumir el Api que se me compartió para esta prueba,

Si embargo logre utilizar algo como un slider para que el comic lograra su objetivo de mostrar las imagenes

Aleatorias.

2.Otro problema que se me presento fue tratar de incluir la tecnología LESS para crear la forma interactiva para que el usuario,

Pudiera calificar el comic, luego descargue XAMPP Y ejecute la prueba desde este servidor local y funciono.


Como ejecutar la prueba.
Descargar Xampp
Xampp CONTROL PANEL: Activar Apache.
Abrir la carpeta xampp, luego copiar el archivo enviado en la carpeta htdocs

y luego abrir la ruta de esta forma http://localhost:8080/Prueba/prueba.html

Nota: tambien se podria ejecutar solo dando click a prueba, pero los estilos LESS no se verian.

Muchas gracias! quedo atenta a todo!!







